package com.andhie.cuticutimelaka;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // find the listview
        ListView listView = (ListView) findViewById(R.id.listView);

        // create adapter and set it to our listview
        final TempatAdapter adapter = new TempatAdapter(this);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                Tempat item = (Tempat) parent.getAdapter().getItem(position);

                Intent detailIntent = new Intent(MainActivity.this, TempatDetailActivity.class);
                detailIntent.putExtra("tempat_data", item);
                startActivity(detailIntent);
            }
        });

        new AsyncTask<Void, Void, List<Tempat>>() {

            @Override
            protected List<Tempat> doInBackground(Void... params) {

                StringBuilder result = new StringBuilder();
                List<Tempat> list = new ArrayList<Tempat>();

                HttpURLConnection urlConnection = null;
                try {
                    URL url = new URL("https://github.com/andhie/Cuti-Cuti-Melaka/raw/master/data/data.json");
                    urlConnection = (HttpURLConnection) url.openConnection();
                    InputStream in = new BufferedInputStream(urlConnection.getInputStream());

                    BufferedReader reader = new BufferedReader(new InputStreamReader(in));

                    String line;
                    while ((line = reader.readLine()) != null) {
                        result.append(line);
                    }

                    // our JSON result in String
                    String json = result.toString();

                    // start to parse our JSON
                    JSONArray jsonArray = new JSONArray(json);
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject jsonObject = jsonArray.getJSONObject(i);
                        String name = jsonObject.getString("name");
                        String address = jsonObject.getString("address");
                        String description = jsonObject.getString("description");
                        String tel = jsonObject.getString("tel");
                        double latitude = jsonObject.getDouble("latitude");
                        double longitude = jsonObject.getDouble("longitude");

                        Tempat tempatMenarik = new Tempat();
                        tempatMenarik.setName(name);
                        tempatMenarik.setAddress(address);
                        tempatMenarik.setDescription(description);
                        tempatMenarik.setTel(tel);
                        tempatMenarik.setLatitude(latitude);
                        tempatMenarik.setLongitude(longitude);

                        list.add(tempatMenarik);

                    }


                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    if (urlConnection != null) {
                        urlConnection.disconnect();
                    }
                }

                return list;
            }

            @Override
            protected void onPostExecute(List<Tempat> tempats) {
                super.onPostExecute(tempats);
                adapter.addAll(tempats);
            }
        }.execute();

    }
}
