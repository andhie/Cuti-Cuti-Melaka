package com.andhie.cuticutimelaka;


import android.os.Parcel;
import android.os.Parcelable;

public class Tempat implements Parcelable {

    private String name;
    private String address;
    private String description;
    private String tel;
    private double latitude;
    private double longitude;

    public Tempat() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    protected Tempat(Parcel in) {
        name = in.readString();
        address = in.readString();
        description = in.readString();
        tel = in.readString();
        latitude = in.readDouble();
        longitude = in.readDouble();
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(name);
        dest.writeString(address);
        dest.writeString(description);
        dest.writeString(tel);
        dest.writeDouble(latitude);
        dest.writeDouble(longitude);
    }

    @SuppressWarnings("unused")
    public static final Parcelable.Creator<Tempat> CREATOR = new Parcelable.Creator<Tempat>() {
        @Override
        public Tempat createFromParcel(Parcel in) {
            return new Tempat(in);
        }

        @Override
        public Tempat[] newArray(int size) {
            return new Tempat[size];
        }
    };
}
