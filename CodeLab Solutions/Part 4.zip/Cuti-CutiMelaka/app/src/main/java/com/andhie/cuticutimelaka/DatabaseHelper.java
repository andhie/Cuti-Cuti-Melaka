package com.andhie.cuticutimelaka;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.provider.BaseColumns;
import android.util.Log;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String TAG = DatabaseHelper.class.getSimpleName();

    public static final String TABLE_NAME = "tempat_table";

    // all our column names, declare as constant
    public static final String _ID = BaseColumns._ID;
    public static final String NAME = "name";
    public static final String ADDRESS = "address";
    public static final String DESCRIPTION = "desc";
    public static final String TEL = "tel";
    public static final String LAT = "lat";
    public static final String LNG = "lng";

    public static final String DATABASE_FILE_NAME = "database.db";

    /**
     * Use to identify the current database version,
     * this needs to change when you change the schema/table.
     * {@link SQLiteOpenHelper#onUpgrade(SQLiteDatabase, int, int)} will be
     * called when existing database version and the declared version differs
     */
    private static final int DATABASE_VERSION = 1;

    // @formatter:off
    public static final String SQL_CREATE_TABLE_TEMPAT_TABLE = "CREATE TABLE IF NOT EXISTS "
            + TABLE_NAME + " ( "
            + _ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
            + NAME + " TEXT, "
            + ADDRESS + " TEXT, "
            + DESCRIPTION + " TEXT, "
            + TEL + " TEXT, "
            + LAT + " REAL, "
            + LNG + " REAL "
            + " );";

    // @formatter:on

    public DatabaseHelper(Context context) {
        super(context, DATABASE_FILE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        if (BuildConfig.DEBUG) Log.d(TAG, "onCreate");
        db.execSQL(SQL_CREATE_TABLE_TEMPAT_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // todo handle when database schema has change
        throw new UnsupportedOperationException("TODO: Implement onUpgrade");
    }
}
