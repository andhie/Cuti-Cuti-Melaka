package com.andhie.cuticutimelaka;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    TempatAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // find the listview
        ListView listView = (ListView) findViewById(R.id.listView);

        // create adapter and set it to our listview
        adapter = new TempatAdapter(this);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                Tempat item = (Tempat) parent.getAdapter().getItem(position);

                Intent detailIntent = new Intent(MainActivity.this, TempatDetailActivity.class);
                detailIntent.putExtra("tempat_data", item);
                startActivity(detailIntent);
            }
        });

        Intent myService = new Intent(this, FetchTempatService.class);
        startService(myService);


        // register to listen to TEMPAT_DATA_GET event
        LocalBroadcastManager.getInstance(this)
                .registerReceiver(mMessageReceiver, new IntentFilter("TEMPAT_DATA_GET"));
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // unregister
        LocalBroadcastManager.getInstance(this)
                .unregisterReceiver(mMessageReceiver);

    }

    private BroadcastReceiver mMessageReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            // Get extra data included in the Intent
            String json = intent.getStringExtra("message");

            // start to parse JSON into List<Tempat> and set into adapter
            FetchDataTask task = new FetchDataTask();
            task.execute(json);
        }
    };

    class FetchDataTask extends AsyncTask<String, Void, List<Tempat>> {

        @Override
        protected List<Tempat> doInBackground(String... params) {

            String json = params[0];

            List<Tempat> list = new ArrayList<Tempat>();

            try {

                // start to parse our JSON
                JSONArray jsonArray = new JSONArray(json);
                for (int i = 0; i < jsonArray.length(); i++) {
                    // read each key-value pair
                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                    String name = jsonObject.getString("name");
                    String address = jsonObject.getString("address");
                    String description = jsonObject.getString("description");
                    String tel = jsonObject.getString("tel");
                    double latitude = jsonObject.getDouble("latitude");
                    double longitude = jsonObject.getDouble("longitude");

                    // update the Tempat object with our data
                    Tempat tempatMenarik = new Tempat();
                    tempatMenarik.setName(name);
                    tempatMenarik.setAddress(address);
                    tempatMenarik.setDescription(description);
                    tempatMenarik.setTel(tel);
                    tempatMenarik.setLatitude(latitude);
                    tempatMenarik.setLongitude(longitude);

                    // add to the end of our List<Tempat>
                    list.add(tempatMenarik);

                }

            } catch (Exception e) {
                e.printStackTrace();
            }

            // return our List, can be empty list or some Tempat data
            return list;
        }

        @Override
        protected void onPostExecute(List<Tempat> tempats) {
            super.onPostExecute(tempats);
            // add all into our adapter to display it
            adapter.addAll(tempats);
        }
    }
}
