package com.andhie.cuticutimelaka;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    TempatAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // find the listview
        ListView listView = (ListView) findViewById(R.id.listView);

        // create adapter and set it to our listview
        adapter = new TempatAdapter(this);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                Tempat item = (Tempat) parent.getAdapter().getItem(position);

                Intent detailIntent = new Intent(MainActivity.this, TempatDetailActivity.class);
                detailIntent.putExtra("tempat_data", item);
                startActivity(detailIntent);
            }
        });

        // start our service to fetch data
        Intent intent = new Intent(this, FetchTempatService.class);
        startService(intent);

        // we try to load our data from DB while waiting for our service to update data
        // so users wont have to wait a long time to see something. Good User Experience!
        new FetchDataTask().execute();

        // register to listen to TEMPAT_DATA_GET event
        LocalBroadcastManager.getInstance(this)
                .registerReceiver(mMessageReceiver, new IntentFilter("TEMPAT_DATA_GET"));
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // unregister
        LocalBroadcastManager.getInstance(this)
                .unregisterReceiver(mMessageReceiver);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_about_us) {
            startActivity(new Intent(this, AboutActivity.class));
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private BroadcastReceiver mMessageReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            // start to parse JSON into List<Tempat> and set into adapter
            FetchDataTask task = new FetchDataTask();
            task.execute();
        }
    };

    class FetchDataTask extends AsyncTask<Void, Void, List<Tempat>> {

        @Override
        protected List<Tempat> doInBackground(Void... params) {


            List<Tempat> list = new ArrayList<>();

            DatabaseHelper dbHelper = new DatabaseHelper(getApplicationContext());
            SQLiteDatabase db = dbHelper.getReadableDatabase();

            Cursor cursor = db.query(DatabaseHelper.TABLE_NAME, //query from kedai_table
                    null, // null means all columns. eg `new String[] {DatabaseHelper.Lat, ...}`
                    null, // null means no WHERE clause. eg `" DatabaseHelper.STATE=?"
                    null, // null because we have no args, eg `new String[] {"SELANGOR"}`
                    null, // null means we dont want to groupBy
                    null, // null means we dont want to filter having
                    null);// null means dont want to orderBy. eg. `DatabaseHelper.STATE + " DESC";

            // need to find out the index of the column in this cursor
            // e.g. when query, submitting column `new String[] {DatabaseHelper.Lng, DatabaseHelper.Lat}
            // Lng will be at column 0, lat will be column 1
            int nameColIndex = cursor.getColumnIndex(DatabaseHelper.NAME);
            int addressColIndex = cursor.getColumnIndex(DatabaseHelper.ADDRESS);
            int stateColIndex = cursor.getColumnIndex(DatabaseHelper.DESCRIPTION);
            int telColIndex = cursor.getColumnIndex(DatabaseHelper.TEL);
            int latColIndex = cursor.getColumnIndex(DatabaseHelper.LAT);
            int lngColIndex = cursor.getColumnIndex(DatabaseHelper.LNG);

            // loop thru our Cursor to read each row
            while (cursor.moveToNext()) {
                Tempat kedai = new Tempat();
                kedai.setName(cursor.getString(nameColIndex));
                kedai.setAddress(cursor.getString(addressColIndex));
                kedai.setDescription(cursor.getString(stateColIndex));
                kedai.setTel(cursor.getString(telColIndex));
                kedai.setLatitude(cursor.getDouble(latColIndex));
                kedai.setLongitude(cursor.getDouble(lngColIndex));

                // add it to our list
                list.add(kedai);
            }

            // close the cursor
            cursor.close();

            // dont forget to close DB
            db.close();

            // return the list back to the Main/UI thread
            return list;
        }

        @Override
        protected void onPostExecute(List<Tempat> tempats) {
            super.onPostExecute(tempats);
            // add all into our adapter to display it
            adapter.addAll(tempats);
        }
    }
}
