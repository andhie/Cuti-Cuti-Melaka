package com.andhie.cuticutimelaka;

import android.app.IntentService;
import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v4.content.LocalBroadcastManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;


public class FetchTempatService extends IntentService {

    public FetchTempatService() {
        super("FetchTempatService");
    }

    @Override
    protected void onHandleIntent(Intent intent) {
        StringBuilder result = new StringBuilder();
        HttpURLConnection urlConnection = null;

        try {
            URL url = new URL("https://github.com/andhie/Cuti-Cuti-Melaka/raw/master/data/data.json");
            urlConnection = (HttpURLConnection) url.openConnection();
            InputStream in = new BufferedInputStream(urlConnection.getInputStream());

            BufferedReader reader = new BufferedReader(new InputStreamReader(in));

            String line;
            while ((line = reader.readLine()) != null) {
                result.append(line);
            }

            String json = result.toString();

            // create an instance to DB and get a writable DB
            DatabaseHelper dbHelper = new DatabaseHelper(this);
            SQLiteDatabase db = dbHelper.getWritableDatabase();
            db.beginTransaction();

            // remove all existing data or else we will have duplicates
            db.delete(DatabaseHelper.TABLE_NAME, null, null);


            // the data begins with "[" means an Array
            JSONArray jsonArray = new JSONArray(json);
            // treat it like usual array/list, just loop thru the end
            for (int i = 0, size = jsonArray.length(); i < size; i++) {
                // get each object out
                JSONObject obj = jsonArray.getJSONObject(i);

                // extract the values based on the Key that we know
                // sample JSON data:
                //
                // { "address" : "Jalan D' Albuquerque, 75050 Ujong Pasir,  Melaka.",
                //   "id" : 188,
                //   "latitude" : 2.110662,
                //   "longitude" : 102.160232,
                //   "name" : "Perkampungan Portugis (Portuguese Square)",
                //   "description" : "Inferring strong affinity to Portugal,...",
                //   "tel" : "06-2847493"
                // }
                //
                ContentValues cv = new ContentValues();
                cv.put(DatabaseHelper.NAME, obj.getString("name"));
                cv.put(DatabaseHelper.ADDRESS, obj.getString("address"));
                cv.put(DatabaseHelper.DESCRIPTION, obj.getString("description"));
                cv.put(DatabaseHelper.TEL, obj.getString("tel"));
                cv.put(DatabaseHelper.LAT, obj.getDouble("latitude"));
                cv.put(DatabaseHelper.LNG, obj.getDouble("longitude"));

                // insert in our database
                db.insert(DatabaseHelper.TABLE_NAME, null, cv);
            }

            // declare our transaction is successful
            db.setTransactionSuccessful();
            // finish any transaction in a batch
            db.endTransaction();

            // remember to close our DB
            db.close();
        } catch (Exception e) {
            e.printStackTrace();

        } finally {
            if (urlConnection != null) {
                urlConnection.disconnect();
            }
        }

        // send a broadcast of finish obtain data
        Intent eventIntent = new Intent("TEMPAT_DATA_GET");
        LocalBroadcastManager.getInstance(this)
                .sendBroadcast(eventIntent);
    }

}
