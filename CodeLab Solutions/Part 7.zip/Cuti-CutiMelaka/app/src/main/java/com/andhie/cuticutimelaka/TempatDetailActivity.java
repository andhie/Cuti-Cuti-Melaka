package com.andhie.cuticutimelaka;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;

public class TempatDetailActivity extends AppCompatActivity implements View.OnClickListener {

    TextView callView;
    TextView mapView;
    Tempat item;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tempat_detail);

        // find all views
        TextView nameView = (TextView) findViewById(R.id.name);
        TextView addressView = (TextView) findViewById(R.id.address);
        TextView descView = (TextView) findViewById(R.id.desc);
        callView = (TextView) findViewById(R.id.call);
        mapView = (TextView) findViewById(R.id.map);

        // get the Tempat data back from Intent data
        item = getIntent().getParcelableExtra("tempat_data");

        // update our views with data
        nameView.setText(item.getName());
        addressView.setText(item.getAddress());
        descView.setText(item.getDescription());
        callView.setText(item.getTel());

        // listen to clicks
        callView.setOnClickListener(this);
        mapView.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.call) {
            String tel = item.getTel();
            Uri telUri = Uri.parse("tel:" + tel);

            Intent callIntent = new Intent(Intent.ACTION_DIAL);
            callIntent.setData(telUri);
            startActivity(callIntent);

        } else if (v == mapView) {
            Intent mapIntent = new Intent(this, MapsActivity.class);
            mapIntent.putExtra("tempat_data", item);
            startActivity(mapIntent);
        }
    }
}
