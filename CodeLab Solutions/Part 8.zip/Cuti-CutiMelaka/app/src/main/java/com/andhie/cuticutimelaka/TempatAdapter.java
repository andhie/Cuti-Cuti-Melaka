package com.andhie.cuticutimelaka;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;


public class TempatAdapter extends ArrayAdapter<Tempat> {

    public TempatAdapter(Context context) {
        super(context, 0);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        ViewHolder holder;
        if (convertView == null) {
            convertView = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.list_item_tempat, parent, false);

            holder = new ViewHolder();
            holder.nameTempat = (TextView) convertView.findViewById(R.id.name);
            holder.addrTempat = (TextView) convertView.findViewById(R.id.address);

            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        Tempat item = getItem(position);

        holder.nameTempat.setText(item.getName());
        holder.addrTempat.setText(item.getAddress());

        return convertView;
    }

    static class ViewHolder {
        TextView nameTempat;
        TextView addrTempat;
    }

}
